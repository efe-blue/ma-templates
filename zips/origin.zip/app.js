/**
 * @file 小程序入口
 * @author
 */
App({
    onLaunch() {
        // SWAN launch
    },
    onShow() {
        // SWAN展现
    },
    onHide() {
        // SWAN当前处于后台
    },
    onError() {
        // SWAN发生错误
    },
    globalData: 'SWAN'
});
