/**
 * @file config.js
 * @author xxx
 */

let devConfig = {
    host: 'xxx',
    shareUrl: 'xxx'
};

let proConfig = {
    host: 'xxx',
    shareUrl: 'xxx'
};

let qaConfig = {
    host: 'xxx',
    shareUrl: 'xxx'
};

export let config = {
    dev: devConfig,
    pro: proConfig,
    qa: qaConfig
};
