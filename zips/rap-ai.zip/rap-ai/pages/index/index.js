/**
 * @file index.js
 * @author xxx
 */

Page({
    data: {
        msg: 'Hello world!'
    }
});
