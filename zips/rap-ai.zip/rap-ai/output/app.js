/**
 * @file app.js
 * @author xxx
 */

/* globals App swan */

/* eslint-disable babel/new-cap */


import {config} from './include/config';

let env = '';
// removeIf(!production)
env = 'pro';
// endRemoveIf(!production)
let envConfig = config[env];

App({
    globalData: {},

    onLaunch() {},

    onShow() {},

    onHide() {},

    onError() {}
});
