/**
 * @file index.js
 * @author xxx
 */

/* globals Page swan getApp getCurrentPages */

/* eslint-disable babel/new-cap */


Page({
    data: {
        msg: 'Hello world!'
    }
});
