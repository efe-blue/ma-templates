/**
 * @file config.js
 * @author liuchaofan@baidu.com
 */

let devConfig = {
    host: 'xxx',
    shareUrl: 'xxx'
};

let proConfig = {
    host: 'xxx',
    shareUrl: 'xxx'
};

let qaConfig = {
    host: 'xxx',
    shareUrl: 'xxx'
};

export let config = {
    dev: devConfig,
    pro: proConfig,
    qa: qaConfig
};
