<template>
    <view class="hello-wrap">
    </view>
</template>
<script>
export default {
    config: {
    },

    components: {
    },

    props: {
    },

    data: {
    },

    methods: {
    }
};
</script>
<style lang="stylus">
</style>
